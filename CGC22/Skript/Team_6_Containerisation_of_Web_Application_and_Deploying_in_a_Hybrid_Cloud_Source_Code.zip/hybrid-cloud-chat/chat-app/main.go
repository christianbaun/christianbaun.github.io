package main

import "github.com/Ta-SeenJunaid/hybrid-cloud-chat/chat-app/pkg/app"

func main() {
	app.Run()
}
