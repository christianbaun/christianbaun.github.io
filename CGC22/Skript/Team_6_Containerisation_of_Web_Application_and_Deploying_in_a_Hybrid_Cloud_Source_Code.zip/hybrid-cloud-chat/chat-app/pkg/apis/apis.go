package apis

type Message struct {
	Author string
	Body   string
	Time   string
}
