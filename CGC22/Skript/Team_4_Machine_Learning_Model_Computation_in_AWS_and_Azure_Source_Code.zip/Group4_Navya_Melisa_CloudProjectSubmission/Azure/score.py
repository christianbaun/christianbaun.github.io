import json
import numpy as np
import os
import tensorflow as tf

from azureml.core.model import Model


def init():
    global model
    model_path = Model.get_model_path('chestxray-model-pneu.h5')
    model = tf.keras.models.load_model(model_path)


def run(raw_data):
    data = np.array(json.loads(raw_data)['chest_xray'])
    print(np.shape(data))
    data = np.reshape(data, (1,128,128,3))
    y_hat = model.predict(data)
    print("Executed predictions...")
    result = json.dumps(y_hat.tolist())
    return {"result": result}
