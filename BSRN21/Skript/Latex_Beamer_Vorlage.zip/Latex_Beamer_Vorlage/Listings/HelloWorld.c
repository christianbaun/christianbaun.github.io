#include<stdio.h>
#include<stdlib.h>

int main(int argc, char **argv)
{
	// Gibt Hello World!!! aus	
	printf("Hello World!!!\n");

	return 0;
}
